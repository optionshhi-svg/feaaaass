@cd /d "%~dp0"
xmrig.exe --coin XMR --url "xmr.kryptex.network:7029" --user 8BFk5LW1AsfLYwRk12L7GTDQ7dMte2YeSR86AKqq6ZMGCkyoHyjW68HHU1iEaQR6zCZtwQt6VZr7MhZPgzKvFgeS6KHfELA/MyRig -p x -k

